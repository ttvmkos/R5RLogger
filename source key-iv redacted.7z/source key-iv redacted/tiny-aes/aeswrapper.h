#pragma once
#include <string>

std::string doEncrypt(const std::string& plainText, const std::string& keyHex, const std::string& ivHex);